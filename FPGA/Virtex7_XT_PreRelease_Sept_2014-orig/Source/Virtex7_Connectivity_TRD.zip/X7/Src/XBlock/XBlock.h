#include <windows.h>

#include <ntverp.h>

#define VER_FILETYPE                VFT_DRV
#define VER_FILESUBTYPE             VFT2_DRV_SYSTEM
#define VER_FILEDESCRIPTION_STR     "WDF Driver for Xilinx V7 Block Driver"
#define VER_INTERNALNAME_STR        "XBlock.sys"
#define VER_ORIGINALFILENAME_STR    "XBlock.sys"

#include "common.ver"




